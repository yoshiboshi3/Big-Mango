package com.xrealcanvas.bridge;

import com.xrealcanvas.bridge.CommandResult;

interface IProofUserService {
    int uid();
    CommandResult launch(int displayId, String component);
    CommandResult tap(int displayId, int x, int y);
    void destroy();
}
