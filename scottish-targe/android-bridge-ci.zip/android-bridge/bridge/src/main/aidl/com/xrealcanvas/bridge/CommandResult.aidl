package com.xrealcanvas.bridge;
parcelable CommandResult;
