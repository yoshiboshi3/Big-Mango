package com.xrealcanvas.bridge

import android.content.Context
import android.os.Process
import android.util.Log
import androidx.annotation.Keep
import java.io.BufferedReader
import java.io.InputStreamReader

class ProofUserService() : IProofUserService.Stub() {
    companion object {
        private const val TAG = "XREALCanvasProof"
    }

    @Keep
    constructor(context: Context) : this() {
        Log.i(TAG, "ProofUserService created with context=${context.packageName}")
    }

    override fun uid(): Int = Process.myUid()

    override fun launch(displayId: Int, component: String): CommandResult =
        execute(ShellCommand.launchComponent(displayId, component))

    override fun tap(displayId: Int, x: Int, y: Int): CommandResult =
        execute(ShellCommand.tap(displayId, x, y))

    override fun destroy() {
        Log.i(TAG, "ProofUserService destroy")
        System.exit(0)
    }

    private fun execute(args: List<String>): CommandResult {
        Log.i(TAG, "shell uid=${Process.myUid()} exec=${args.joinToString(" ")}")
        return try {
            val process = ProcessBuilder(args)
                .redirectErrorStream(true)
                .start()
            val output = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }
            val exit = process.waitFor()
            CommandResult(exit, output.trim())
        } catch (t: Throwable) {
            Log.e(TAG, "command failed", t)
            CommandResult(-1, "${t.javaClass.name}: ${t.message.orEmpty()}")
        }
    }
}
