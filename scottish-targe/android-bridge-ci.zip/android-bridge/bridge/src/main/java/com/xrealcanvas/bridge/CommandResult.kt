package com.xrealcanvas.bridge

import android.os.Parcel
import android.os.Parcelable

data class CommandResult(
    val exitCode: Int,
    val output: String
) : Parcelable {
    private constructor(parcel: Parcel) : this(
        exitCode = parcel.readInt(),
        output = parcel.readString().orEmpty()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(exitCode)
        parcel.writeString(output)
    }

    override fun describeContents(): Int = 0

    fun compact(): String = "exit=$exitCode\n$output"

    companion object CREATOR : Parcelable.Creator<CommandResult> {
        override fun createFromParcel(parcel: Parcel): CommandResult = CommandResult(parcel)
        override fun newArray(size: Int): Array<CommandResult?> = arrayOfNulls(size)
    }
}
