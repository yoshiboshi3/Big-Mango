package com.xrealcanvas.bridge

import android.app.Activity
import android.content.Context
import android.content.Intent
import java.util.concurrent.atomic.AtomicReference

object XrealCanvasBridge {
    private val selectedComponent = AtomicReference<String?>(null)

    @Volatile
    private var displaySession: VirtualDisplaySession? = null

    @Volatile
    private var lastLaunchResult: CommandResult = CommandResult(-1, "not_run")

    @Volatile
    private var lastTapResult: CommandResult = CommandResult(-1, "not_run")

    @JvmStatic
    fun initializeShizuku(activity: Activity): String = ShizukuProofClient.initialize(activity)

    @JvmStatic
    fun shizukuStatus(): String = ShizukuProofClient.status()

    @JvmStatic
    fun shizukuServerUid(): Int = ShizukuProofClient.serverUid()

    @JvmStatic
    fun shizukuServiceUid(): Int = ShizukuProofClient.serviceUid()

    @JvmStatic
    fun shizukuReady(): Boolean = ShizukuProofClient.ready()

    @JvmStatic
    fun launchOnDisplay(displayId: Int, component: String): String {
        val result = ShizukuProofClient.launch(displayId, component)
        lastLaunchResult = result
        return result.compact()
    }

    @JvmStatic
    fun tap(displayId: Int, x: Int, y: Int): String {
        val result = ShizukuProofClient.tap(displayId, x, y)
        lastTapResult = result
        return result.compact()
    }

    @JvmStatic
    fun lastLaunchExitCode(): Int = lastLaunchResult.exitCode

    @JvmStatic
    fun lastLaunchOutput(): String = lastLaunchResult.output

    @JvmStatic
    fun lastTapExitCode(): Int = lastTapResult.exitCode

    @JvmStatic
    fun lastTapOutput(): String = lastTapResult.output

    @JvmStatic
    fun openPicker(activity: Activity) {
        activity.startActivity(Intent(activity, AppPickerActivity::class.java))
    }

    @JvmStatic
    fun consumeSelectedComponent(): String? = selectedComponent.getAndSet(null)

    internal fun setSelectedComponent(component: String) {
        selectedComponent.set(component)
    }

    @JvmStatic
    @Synchronized
    fun startVirtualDisplay(context: Context): Int {
        val session = displaySession ?: VirtualDisplaySession(context).also { displaySession = it }
        return session.start()
    }

    @JvmStatic
    @Synchronized
    fun stopVirtualDisplay() {
        displaySession?.stop()
        displaySession = null
    }

    @JvmStatic
    fun latestFrame(): ByteArray? = displaySession?.latestFrame()

    @JvmStatic
    fun frameCount(): Long = displaySession?.frameCount ?: 0L

    @JvmStatic
    fun lastFrameNanos(): Long = displaySession?.lastFrameNanos ?: 0L

    @JvmStatic
    fun virtualDisplayId(): Int = displaySession?.let {
        try {
            it.start()
        } catch (_: Throwable) {
            -1
        }
    } ?: -1
}
