package com.xrealcanvas.bridge

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

object AppCatalog {
    fun list(context: Context): List<LaunchableApp> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)

        val resolved = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(
                intent,
                PackageManager.ResolveInfoFlags.of(PackageManager.MATCH_ALL.toLong())
            )
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        }

        return resolved
            .asSequence()
            .mapNotNull { info ->
                val activity = info.activityInfo ?: return@mapNotNull null
                if (activity.packageName == context.packageName) return@mapNotNull null
                LaunchableApp(
                    label = info.loadLabel(pm)?.toString()?.ifBlank { activity.packageName }
                        ?: activity.packageName,
                    packageName = activity.packageName,
                    activityName = activity.name
                )
            }
            .distinctBy { it.packageName to it.activityName }
            .sortedWith { a, b -> a.label.compareTo(b.label, ignoreCase = true) }
            .toList()
    }
}
