package com.xrealcanvas.bridge

object ShellCommand {
    fun launchComponent(displayId: Int, component: String): List<String> {
        require(displayId >= 0) { "displayId must be non-negative" }
        require(component.isNotBlank()) { "component must not be blank" }
        return listOf(
            "am", "start", "-W", "--display", displayId.toString(), "-n", component
        )
    }

    fun tap(displayId: Int, x: Int, y: Int): List<String> {
        require(displayId >= 0) { "displayId must be non-negative" }
        require(x >= 0 && y >= 0) { "tap coordinates must be non-negative" }
        return listOf(
            "input", "-d", displayId.toString(), "tap", x.toString(), y.toString()
        )
    }
}
