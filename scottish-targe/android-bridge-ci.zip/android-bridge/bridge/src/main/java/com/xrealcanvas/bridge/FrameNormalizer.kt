package com.xrealcanvas.bridge

import java.nio.ByteBuffer

object FrameNormalizer {
    fun copyRgba(
        buffer: ByteBuffer,
        width: Int,
        height: Int,
        pixelStride: Int,
        rowStride: Int
    ): ByteArray {
        require(width > 0) { "width must be > 0" }
        require(height > 0) { "height must be > 0" }
        require(pixelStride == 4) { "RGBA_8888 requires pixelStride 4, got $pixelStride" }

        val rowBytes = width * pixelStride
        require(rowStride >= rowBytes) {
            "rowStride $rowStride is smaller than row bytes $rowBytes"
        }

        val out = ByteArray(rowBytes * height)
        val source = buffer.duplicate()
        for (y in 0 until height) {
            source.position(y * rowStride)
            source.get(out, y * rowBytes, rowBytes)
        }
        return out
    }
}
