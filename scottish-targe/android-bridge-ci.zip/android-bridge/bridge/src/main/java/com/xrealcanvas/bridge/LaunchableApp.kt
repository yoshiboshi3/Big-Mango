package com.xrealcanvas.bridge

data class LaunchableApp(
    val label: String,
    val packageName: String,
    val activityName: String
) {
    fun flattenedComponent(): String = "$packageName/$activityName"
}
