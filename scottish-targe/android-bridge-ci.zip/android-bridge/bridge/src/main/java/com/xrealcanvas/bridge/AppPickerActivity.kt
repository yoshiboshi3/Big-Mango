package com.xrealcanvas.bridge

import android.app.Activity
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView

class AppPickerActivity : Activity() {
    private lateinit var apps: List<LaunchableApp>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Scottish Targe — Add Window"

        apps = AppCatalog.list(this)
        val root = FrameLayout(this)
        val list = ListView(this)
        val empty = TextView(this).apply {
            text = "No launchable apps found"
            gravity = Gravity.CENTER
            textSize = 18f
            setTextColor(Color.DKGRAY)
        }

        list.adapter = AppAdapter(this, apps)
        list.emptyView = empty
        list.setOnItemClickListener { _, _, position, _ ->
            val app = apps[position]
            XrealCanvasBridge.setSelectedComponent(app.flattenedComponent())
            setResult(RESULT_OK)
            finish()
        }

        root.addView(
            list,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        root.addView(
            empty,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        setContentView(root)
    }

    private class AppAdapter(
        private val context: Context,
        private val items: List<LaunchableApp>
    ) : BaseAdapter() {
        private val pm = context.packageManager
        private val iconSize = (48f * context.resources.displayMetrics.density).toInt()
        private val pad = (12f * context.resources.displayMetrics.density).toInt()

        override fun getCount(): Int = items.size
        override fun getItem(position: Int): LaunchableApp = items[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val row = (convertView as? android.widget.LinearLayout) ?: android.widget.LinearLayout(context).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(pad, pad, pad, pad)

                addView(ImageView(context).apply { id = android.R.id.icon }, android.widget.LinearLayout.LayoutParams(iconSize, iconSize))
                addView(TextView(context).apply {
                    id = android.R.id.text1
                    textSize = 17f
                    setPadding(pad, 0, 0, 0)
                    setTextColor(Color.BLACK)
                }, android.widget.LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            }

            val item = getItem(position)
            row.findViewById<TextView>(android.R.id.text1).text = item.label
            val iconView = row.findViewById<ImageView>(android.R.id.icon)
            iconView.setImageDrawable(
                try {
                    pm.getApplicationIcon(item.packageName)
                } catch (_: Throwable) {
                    context.getDrawable(android.R.drawable.sym_def_app_icon)
                }
            )
            return row
        }
    }
}
