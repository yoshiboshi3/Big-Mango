package com.xrealcanvas.bridge

import android.app.Activity
import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.util.Log
import rikka.shizuku.Shizuku
import java.lang.ref.WeakReference

internal object ShizukuProofClient {
    private const val TAG = "XREALCanvasProof"
    private const val REQUEST_CODE = 42017
    private const val SERVICE_VERSION = 1

    @Volatile private var statusValue = "not_initialized"
    @Volatile private var serverUidValue = -1
    @Volatile private var serviceUidValue = -1
    @Volatile private var service: IProofUserService? = null

    private var activityRef = WeakReference<Activity>(null)
    private var userServiceArgs: Shizuku.UserServiceArgs? = null
    private var listenersInstalled = false

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName, binder: IBinder) {
            val candidate = IProofUserService.Stub.asInterface(binder)
            try {
                val uid = candidate.uid()
                serviceUidValue = uid
                if (uid != 2000) {
                    statusValue = if (uid == 0) "rejected_root_user_service" else "rejected_user_service_uid_$uid"
                    service = null
                    Log.e(TAG, "Rejecting Shizuku UserService uid=$uid")
                    return
                }
                service = candidate
                statusValue = "ready"
                Log.i(TAG, "Shizuku UserService ready uid=$uid")
            } catch (t: Throwable) {
                service = null
                statusValue = "service_handshake_failed:${t.javaClass.simpleName}"
                Log.e(TAG, "UserService handshake failed", t)
            }
        }

        override fun onServiceDisconnected(name: ComponentName) {
            service = null
            serviceUidValue = -1
            statusValue = "service_disconnected"
            Log.w(TAG, "Shizuku UserService disconnected")
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        Log.i(TAG, "Shizuku binder received")
        continueInitialization()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        service = null
        serviceUidValue = -1
        serverUidValue = -1
        statusValue = "binder_dead"
        Log.w(TAG, "Shizuku binder died")
    }

    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode != REQUEST_CODE) return@OnRequestPermissionResultListener
        if (grantResult == PackageManager.PERMISSION_GRANTED) {
            statusValue = "permission_granted"
            bindUserService()
        } else {
            statusValue = "permission_denied"
        }
    }

    @Synchronized
    fun initialize(activity: Activity): String {
        activityRef = WeakReference(activity)
        if (userServiceArgs == null) {
            userServiceArgs = Shizuku.UserServiceArgs(
                ComponentName(activity.packageName, ProofUserService::class.java.name)
            )
                .daemon(false)
                .processNameSuffix("scottish_targe_proof")
                .debuggable(BuildConfig.DEBUG)
                .version(SERVICE_VERSION)
        }

        if (!listenersInstalled) {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionResultListener)
            listenersInstalled = true
        }

        statusValue = if (Shizuku.pingBinder()) "binder_available" else "waiting_for_binder"
        if (Shizuku.pingBinder()) continueInitialization()
        return statusValue
    }

    private fun continueInitialization() {
        val activity = activityRef.get() ?: run {
            statusValue = "activity_unavailable"
            return
        }

        try {
            val uid = Shizuku.getUid()
            serverUidValue = uid
            when (uid) {
                2000 -> Unit
                0 -> {
                    statusValue = "rejected_root_shizuku"
                    return
                }
                else -> {
                    statusValue = "rejected_shizuku_uid_$uid"
                    return
                }
            }

            when {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> bindUserService()
                Shizuku.shouldShowRequestPermissionRationale() -> statusValue = "permission_denied_rationale"
                else -> {
                    statusValue = "permission_requested"
                    activity.runOnUiThread { Shizuku.requestPermission(REQUEST_CODE) }
                }
            }
        } catch (t: Throwable) {
            statusValue = "shizuku_error:${t.javaClass.simpleName}"
            Log.e(TAG, "Shizuku initialization failed", t)
        }
    }

    @Synchronized
    private fun bindUserService() {
        if (service != null) {
            statusValue = "ready"
            return
        }
        val args = userServiceArgs ?: run {
            statusValue = "service_args_unavailable"
            return
        }
        try {
            statusValue = "binding_user_service"
            Shizuku.bindUserService(args, serviceConnection)
        } catch (t: Throwable) {
            statusValue = "bind_failed:${t.javaClass.simpleName}"
            Log.e(TAG, "bindUserService failed", t)
        }
    }

    fun status(): String = statusValue
    fun serverUid(): Int = serverUidValue
    fun serviceUid(): Int = serviceUidValue
    fun ready(): Boolean = service != null && serviceUidValue == 2000

    fun launch(displayId: Int, component: String): CommandResult {
        val remote = service ?: return CommandResult(-1, "Shizuku UserService not ready: $statusValue")
        return try {
            remote.launch(displayId, component)
        } catch (t: Throwable) {
            CommandResult(-1, "${t.javaClass.name}: ${t.message.orEmpty()}")
        }
    }

    fun tap(displayId: Int, x: Int, y: Int): CommandResult {
        val remote = service ?: return CommandResult(-1, "Shizuku UserService not ready: $statusValue")
        return try {
            remote.tap(displayId, x, y)
        } catch (t: Throwable) {
            CommandResult(-1, "${t.javaClass.name}: ${t.message.orEmpty()}")
        }
    }
}
