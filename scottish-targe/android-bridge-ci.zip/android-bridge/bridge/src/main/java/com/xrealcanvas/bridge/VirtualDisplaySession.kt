package com.xrealcanvas.bridge

import android.content.Context
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import java.util.concurrent.atomic.AtomicLong

class VirtualDisplaySession(
    context: Context,
    val width: Int = WIDTH,
    val height: Int = HEIGHT,
    val densityDpi: Int = DENSITY_DPI
) {
    companion object {
        const val WIDTH = 960
        const val HEIGHT = 540
        const val DENSITY_DPI = 240
        private const val DISPLAY_NAME = "Scottish Targe Hosted App"
    }

    private val appContext = context.applicationContext
    private val displayManager = appContext.getSystemService(DisplayManager::class.java)
    private val frames = AtomicLong(0)

    @Volatile
    private var latestBytes: ByteArray? = null

    @Volatile
    private var lastFrameNanosValue: Long = 0L

    private var handlerThread: HandlerThread? = null
    private var imageReader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null

    val frameCount: Long
        get() = frames.get()

    val lastFrameNanos: Long
        get() = lastFrameNanosValue

    @Synchronized
    fun start(): Int {
        virtualDisplay?.let { return it.display.displayId }

        val thread = HandlerThread("ScottishTargeVirtualDisplayFrames").also { it.start() }
        val handler = Handler(thread.looper)
        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader.setOnImageAvailableListener({ source ->
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val plane = image.planes.firstOrNull() ?: return@setOnImageAvailableListener
                latestBytes = FrameNormalizer.copyRgba(
                    plane.buffer,
                    image.width,
                    image.height,
                    plane.pixelStride,
                    plane.rowStride
                )
                frames.incrementAndGet()
                lastFrameNanosValue = System.nanoTime()
            } finally {
                image.close()
            }
        }, handler)

        val display = displayManager.createVirtualDisplay(
            DISPLAY_NAME,
            width,
            height,
            densityDpi,
            reader.surface,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY
        ) ?: run {
            reader.close()
            thread.quitSafely()
            throw IllegalStateException("DisplayManager.createVirtualDisplay returned null")
        }

        handlerThread = thread
        imageReader = reader
        virtualDisplay = display
        return display.display.displayId
    }

    fun latestFrame(): ByteArray? = latestBytes

    @Synchronized
    fun stop() {
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
        handlerThread?.quitSafely()
        handlerThread = null
        latestBytes = null
        frames.set(0)
        lastFrameNanosValue = 0L
    }
}
