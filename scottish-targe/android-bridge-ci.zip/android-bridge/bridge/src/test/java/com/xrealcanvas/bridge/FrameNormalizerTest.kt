package com.xrealcanvas.bridge

import org.junit.Assert.assertArrayEquals
import org.junit.Test
import java.nio.ByteBuffer

class FrameNormalizerTest {
    @Test
    fun removesRowPadding() {
        val bytes = byteArrayOf(
            1,2,3,4, 5,6,7,8, 99,99,99,99,
            9,10,11,12, 13,14,15,16, 99,99,99,99
        )
        val out = FrameNormalizer.copyRgba(
            ByteBuffer.wrap(bytes), 2, 2, pixelStride = 4, rowStride = 12
        )
        assertArrayEquals(
            byteArrayOf(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16), out
        )
    }
}
