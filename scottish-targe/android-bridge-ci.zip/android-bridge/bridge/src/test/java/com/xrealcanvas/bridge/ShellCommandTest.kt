package com.xrealcanvas.bridge

import org.junit.Assert.assertEquals
import org.junit.Test

class ShellCommandTest {
    @Test
    fun launchTargetsDisplayAndComponent() {
        assertEquals(
            listOf("am", "start", "-W", "--display", "7", "-n", "com.example/.MainActivity"),
            ShellCommand.launchComponent(7, "com.example/.MainActivity")
        )
    }

    @Test
    fun tapTargetsDisplay() {
        assertEquals(
            listOf("input", "-d", "7", "tap", "400", "200"),
            ShellCommand.tap(7, 400, 200)
        )
    }
}
